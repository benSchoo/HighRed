
#include <SFML/Graphics.hpp>
#include <time.h>
#include "Connector.hpp"
#include <iostream>
#include <iomanip>
using namespace sf;

int size = 56;
Vector2f offset(28, 28);

Sprite f[32];
std::string position = "";

int board[8][8] =
{
    -1,-2,-3,-4,-5,-3,-2,-1,
    -6,-6,-6,-6,-6,-6,-6,-6,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0,
    6, 6, 6, 6, 6, 6, 6, 6,
    1, 2, 3, 4, 5, 3, 2, 1
};

std::string toChessNote(Vector2f p)
{
    std::string s = "";
    s += char(p.x / size + 97);
    s += char(7 - p.y / size + 49);
    return s;
}

Vector2f toCoord(char a, char b)
{
    int x = int(a) - 97;
    int y = 7 - int(b) + 49;
    return Vector2f(x * size, y * size);
}

void move(std::string str)
{
    Vector2f oldPos = toCoord(str[0], str[1]);
    Vector2f newPos = toCoord(str[2], str[3]);

    for (int i = 0; i < 32; i++)
        if (f[i].getPosition() == newPos) f[i].setPosition(-100, -100);

    for (int i = 0; i < 32; i++)
        if (f[i].getPosition() == oldPos) f[i].setPosition(newPos);

    if (str == "e1g1") if (position.find("e1") == -1) move("h1f1");
    if (str == "e8g8") if (position.find("e8") == -1) move("h8f8");
    if (str == "e1c1") if (position.find("e1") == -1) move("a1d1");
    if (str == "e8c8") if (position.find("e8") == -1) move("a8d8");
}
void loadPosition()
{
    int k = 0;
    for (int i = 0;i < 8;i++)
        for (int j = 0;j < 8;j++)
        {
            int n = board[i][j];
            if (!n) continue;
            int x = abs(n) - 1;
            int y = n > 0 ? 1 : 0;
            f[k].setTextureRect(IntRect(size * x, size * y, size, size));
            f[k].setPosition(size * j, size * i);
            k++;
        }

    for (int i = 0;i < position.length();i += 5)
        move(position.substr(i, 4));
}

enum PieceType {
    Queen,
    Rook,
    Bishop,
    Knight
};

bool isPawnPromotionAllowed(const Vector2f& pawnPosition, int pawnColor) {
    int pawnY = static_cast<int>(pawnPosition.y / size);

    if ((pawnColor == 1 && pawnY == 7) || (pawnColor == -1 && pawnY == 0)) {
        return true;
    }

    return false;
}

void displayPromotionMenu(RenderWindow& window, Vector2f promotedPawnPosition) {
    float xOffset = 20.0f;
    float yOffset = 0.0f;

    Texture queenTexture;
    Texture rookTexture;
    Texture bishopTexture;
    Texture knightTexture;

    if (!queenTexture.loadFromFile("images/figures.png") ||
        !rookTexture.loadFromFile("images/figures.png") ||
        !bishopTexture.loadFromFile("images/figures.png") ||
        !knightTexture.loadFromFile("images/figures.png")) {
        
    }

    Sprite queenSprite(queenTexture);
    Sprite rookSprite(rookTexture);
    Sprite bishopSprite(bishopTexture);
    Sprite knightSprite(knightTexture);

    queenSprite.setPosition(promotedPawnPosition + Vector2f(xOffset, yOffset));
    rookSprite.setPosition(queenSprite.getPosition() + Vector2f(xOffset, 0));
    bishopSprite.setPosition(rookSprite.getPosition() + Vector2f(xOffset, 0));
    knightSprite.setPosition(bishopSprite.getPosition() + Vector2f(xOffset, 0));

    window.draw(queenSprite);
    window.draw(rookSprite);
    window.draw(bishopSprite);
    window.draw(knightSprite);
}

bool playerChoosesPromotion(RenderWindow& window, Sprite queenSprite, Sprite rookSprite, Sprite bishopSprite, Sprite knightSprite) {
    Event event;
    bool isChoosingPromotion = true;

    while (isChoosingPromotion) {
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }

            if (event.type == Event::MouseButtonPressed) {
                if (event.mouseButton.button == Mouse::Left) {
                    Vector2i mousePosition = Mouse::getPosition(window);

                    if (queenSprite.getGlobalBounds().contains(static_cast<Vector2f>(mousePosition))) {
                        isChoosingPromotion = false;
                        return true;
                    }
                    else if (rookSprite.getGlobalBounds().contains(static_cast<Vector2f>(mousePosition))) {
                        isChoosingPromotion = false;
                        return true;
                    }
                    else if (bishopSprite.getGlobalBounds().contains(static_cast<Vector2f>(mousePosition))) {
                        isChoosingPromotion = false;
                        return true;
                    }
                    else if (knightSprite.getGlobalBounds().contains(static_cast<Vector2f>(mousePosition))) {
                        isChoosingPromotion = false;
                        return true;
                    }
                }
            }
        }

        sleep(milliseconds(100));
    }

    return false;
}

void promotePawn(PieceType chosenPiece, int pawnColor, Vector2f pawnPosition) {

    int pawnX = static_cast<int>(pawnPosition.x / size);
    int pawnY = static_cast<int>(pawnPosition.y / size);

    int newPiece = -1;

    switch (chosenPiece) {
    case PieceType::Queen:
        newPiece = pawnColor * PieceType::Queen;
        break;
    case PieceType::Rook:
        newPiece = pawnColor * PieceType::Rook;
        break;
    case PieceType::Bishop:
        newPiece = pawnColor * PieceType::Bishop;
        break;
    case PieceType::Knight:
        newPiece = pawnColor * PieceType::Knight;
        break;
    default:
        break;
    }

    if (newPiece != -1) {
        board[pawnY][pawnX] = newPiece;
    }

    for (int i = 0; i < 32; i++) {
        Vector2f piecePosition = f[i].getPosition();
        int pieceX = static_cast<int>(piecePosition.x / size);
        int pieceY = static_cast<int>(piecePosition.y / size);

        if (pieceX == pawnX && pieceY == pawnY) {
            Texture newTexture;

            switch (chosenPiece) {
            case PieceType::Queen:
                if (pawnColor == 1) {
                    newTexture.loadFromFile("images/figures.png");
                }
                else {
                    newTexture.loadFromFile("images/figures.png");
                }
                break;
            case PieceType::Rook:
                if (pawnColor == 1) {
                    newTexture.loadFromFile("images/figures.png");
                }
                else {
                    newTexture.loadFromFile("images/figures.png");
                }
                break;
            case PieceType::Bishop:
                if (pawnColor == 1) {
                    newTexture.loadFromFile("images/figures.png");
                }
                else {
                    newTexture.loadFromFile("images/figures.png");
                }
                break;
            case PieceType::Knight:
                if (pawnColor == 1) {
                    newTexture.loadFromFile("images/figures.png");
                }
                else {
                    newTexture.loadFromFile("images/figures.png");
                }
                break;
            default:
                break;
            }

            f[i].setTexture(newTexture);
        }
    }
}

int main()
{
    try {
        RenderWindow window(VideoMode(504, 504), "Chess! (press SPACE)");

        char enginePath[] = "stockfish.exe";
        ConnectToEngine(enginePath);

        Texture t1, t2;
        t1.loadFromFile("images/figures.png");
        t2.loadFromFile("images/board.png");

        for (int i = 0; i < 32; i++) f[i].setTexture(t1);
        Sprite sBoard(t2);

        loadPosition();

        bool isMove = false;
        float dx = 0, dy = 0;
        Vector2f oldPos, newPos;
        std::string str;
        int n = 0;
        bool isPromotion = false;
        PieceType chosenPiece = Queen;
        Texture queenTexture;
        Texture rookTexture;
        Texture bishopTexture;
        Texture knightTexture;

        if (!queenTexture.loadFromFile("images/figures.png") ||
            !rookTexture.loadFromFile("images/figures.png") ||
            !bishopTexture.loadFromFile("images/figures.png") ||
            !knightTexture.loadFromFile("images/figures.png")) {

        }

        Sprite queenSprite(queenTexture);
        Sprite rookSprite(rookTexture);
        Sprite bishopSprite(bishopTexture);
        Sprite knightSprite(knightTexture);
        int pawnColor = 0;

        while (window.isOpen())
        {
            Vector2i pos = Mouse::getPosition(window) - Vector2i(offset);

            Event e;
            while (window.pollEvent(e))
            {
                if (e.type == Event::Closed)
                {
                    window.close();
                }

                if (e.type == Event::MouseButtonPressed)
                {
                    if (e.key.code == Mouse::Left)
                    {
                        for (int i = 0; i < 32; i++)
                        {
                            if (f[i].getGlobalBounds().contains(pos.x, pos.y))
                            {
                                isMove = true;
                                n = i;
                                dx = pos.x - f[i].getPosition().x;
                                dy = pos.y - f[i].getPosition().y;
                                oldPos = f[i].getPosition();
                                pawnColor = (position.find(" " + toChessNote(oldPos)) != std::string::npos) ? 1 : -1;

                                if (isPawnPromotionAllowed(oldPos, pawnColor))
                                {
                                    isPromotion = true;
                                }
                            }
                        }
                    }
                }

                if (e.type == Event::MouseButtonReleased)
                {
                    if (e.key.code == Mouse::Left)
                    {
                        isMove = false;
                        Vector2f p = f[n].getPosition() + Vector2f(size / 2, size / 2);
                        newPos = Vector2f(size * int(p.x / size), size * int(p.y / size));
                        str = toChessNote(oldPos) + toChessNote(newPos);
                        move(str);
                        if (oldPos != newPos)
                            position += str + " ";
                        f[n].setPosition(newPos);

                        if (isPromotion)
                        {

                            displayPromotionMenu(window, newPos);
                            if (playerChoosesPromotion(window, queenSprite, rookSprite, bishopSprite, knightSprite))
                            {

                                promotePawn(chosenPiece, pawnColor, newPos);
                                isPromotion = false;
                            }
                        }
                    }
                }
            }

            if (Keyboard::isKeyPressed(Keyboard::Space))
            {
                str = getNextMove(position);

                oldPos = toCoord(str[0], str[1]);
                newPos = toCoord(str[2], str[3]);

                for (int i = 0; i < 32; i++) if (f[i].getPosition() == oldPos) n = i;

                for (int k = 0; k < 50; k++)
                {
                    Vector2f p = newPos - oldPos;
                    f[n].move(p.x / 50, p.y / 50);
                    window.draw(sBoard);
                    for (int i = 0; i < 32; i++) f[i].move(offset);
                    for (int i = 0; i < 32; i++) window.draw(f[i]); window.draw(f[n]);
                    for (int i = 0; i < 32; i++) f[i].move(-offset);
                    window.display();
                }

                move(str);  position += str + " ";
                f[n].setPosition(newPos);
            }

            if (isMove) f[n].setPosition(pos.x - dx, pos.y - dy);

            window.clear();
            window.draw(sBoard);
            for (int i = 0; i < 32; i++) f[i].move(offset);
            for (int i = 0; i < 32; i++) window.draw(f[i]); window.draw(f[n]);
            for (int i = 0; i < 32; i++) f[i].move(-offset);
            window.display();
        }

        CloseConnection();

        return 0; 
    }
    catch (const std::exception& e)
    {
        std::cerr << "Exception caught: " << e.what() << std::endl;
    }
    catch (...)
    {
        std::cerr << "Unknown exception caught" << std::endl;
    }
}
